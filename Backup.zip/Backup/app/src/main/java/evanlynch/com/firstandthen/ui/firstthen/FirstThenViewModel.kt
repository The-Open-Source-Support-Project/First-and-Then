package evanlynch.com.firstandthen.ui.firstthen

import androidx.lifecycle.ViewModel

class FirstThenViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
