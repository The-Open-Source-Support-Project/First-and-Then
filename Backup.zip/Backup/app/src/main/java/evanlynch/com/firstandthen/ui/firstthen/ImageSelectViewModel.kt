package evanlynch.com.firstandthen.ui.firstthen

import androidx.lifecycle.ViewModel

class ImageSelectViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
